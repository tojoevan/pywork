---
name: inkspcl-pywork
description: "Inkspcl.com pyWork MCP skill for blog, microblog, notes, comments, topics, LLM configs, and more. Trigger when user asks to publish blog/microblog, write post, create note, comment, create/summarize topic, or any inkspcl.com content. Keywords: 博客, blog, 微博, microblog, 笔记, note, 评论, comment, 话题, topic, inkspcl, pywork MCP."
---

# inkspcl.com pyWork MCP 全功能技能

通过 pyWork MCP server 向 inkspcl.com 发布内容、管理评论、创建话题、配置 LLM 等。

## 配置

MCP server `pywork` 需预先配置在 OpenClaw 的 `openclaw.json` 中：

```json
{
  "mcp": {
    "servers": {
      "pywork": {
        "url": "https://www.inkspcl.com/mcp",
        "headers": {
          "Authorization": "Bearer YOUR_MCP_TOKEN"
        }
      }
    }
  }
}
```

配置后重启 gateway 生效。

## MCP 工具列表（共 32 个工具）

### auth — 认证

| 工具 | 参数 |
|------|------|
| `auth.auth_register` | `username`, `email`, `password` |
| `auth.auth_login` | `username`, `password` |
| `auth.auth_logout` | `token` |
| `auth.auth_get_user` | `user_id` |
| `auth.auth_github_url` | `state` (CSRF 参数) |
| `auth.auth_create_mcp_token` | `name` |
| `auth.auth_list_mcp_tokens` | 无 |

### blog — 博客

| 工具 | 参数 |
|------|------|
| `blog.create_post` | `title`, `content` ⚠️(不是body), `tags`(数组), `status` |
| `blog.search_posts` | `query`, `tag`, `status`, `limit` |
| `blog.update_post` | `id`, `title?`, `content?`, `status?` |
| `blog.delete_post` | `id` |

### microblog — 微博

| 工具 | 参数 |
|------|------|
| `microblog.create_microblog` | `content`, `visibility` |
| `microblog.list_microblog` | `limit` |
| `microblog.delete_microblog` | `id` |

### comments — 评论

| 工具 | 参数 |
|------|------|
| `comments.create_comment` | `target_type`, `target_id`, `content`, `parent_id?` |
| `comments.list_comments` | `target_type`, `target_id` |

### notes — 笔记

| 工具 | 参数 |
|------|------|
| `notes.create_note` | `title`, `content`, `visibility` |
| `notes.list_notes` | `visibility`, `limit` |

### about — 留言板

| 工具 | 参数 |
|------|------|
| `about.submit_guestbook` | `nickname`, `content` |

### topic — 话题讨论

| 工具 | 参数 |
|------|------|
| `topic.create_topic` | `title`, `description`, `deadline_hours` |
| `topic.update_topic` | `topic_id`, `title?`, `description?`, `deadline_hours?` |
| `topic.list_topics` | `status?`, `limit?`, `offset?` |
| `topic.reply_topic` | `topic_id`, `content`, `parent_id?` |
| `topic.vote` | `target_type`, `target_id`, `vote_type` |
| `topic.get_topic_detail` | `topic_id` |
| `topic.summarize_topic` | `topic_id`, `publish_blog?` |

### llm_config — LLM 配置

| 工具 | 参数 |
|------|------|
| `llm_config.list_llm_configs` | 无 |
| `llm_config.create_llm_config` | `name`, `base_url`, `api_key`, `model`, `temperature?`, `max_tokens?`, `system_prompt?`, `is_default?` |
| `llm_config.update_llm_config` | `id`, `name?`, `base_url?`, `api_key?`, `model?`, `temperature?`, `max_tokens?`, `system_prompt?`, `is_default?` |
| `llm_config.delete_llm_config` | `id` |
| `llm_config.test_llm_config` | `id` |
| `llm_config.call_llm` | `prompt`, `config_id?`, `system_prompt?`, `temperature?`, `max_tokens?` |

## 使用方式

**优先使用 MCP 工具直接调用**（如果 OpenClaw 已加载 pywork MCP server，工具会自动出现在可用工具列表中）。

**备选：Python 脚本** — 如果 MCP 工具不可用，使用 `scripts/inkspcl_mcp.py` 脚本通过 JSON-RPC 2.0 直接调用 API：

```bash
python3 scripts/inkspcl_mcp.py blog.create_post \
  --token "YOUR_MCP_TOKEN" \
  --params '{"title":"标题","content":"正文","tags":["标签"]}'
```

## 踩坑记录

- `blog.create_post` 正文参数是 `content`，不是 `body`（API 实际是 content，文档可能有误）
- `blog.create_post` 的 `tags` 参数是**数组**不是逗号分隔字符串，传数组时可能被服务端打散为单字母 → **规避：先用 create_post 不带 tags，再用 update_post 补上 tags 数组**
- 工具名注意：`blog.search_posts`（不是 list_posts）、`microblog.list_microblog`（不是 list_microblogs）
- `comments.create_comment` 需要指定 `target_type`（`blog`/`microblog`/`note`）+ `target_id`
#!/usr/bin/env python3
"""inkspcl.com pyWork MCP client — JSON-RPC 2.0 over HTTP."""

import argparse
import json
import sys
import urllib.request
import urllib.error

MCP_URL = "https://www.inkspcl.com/mcp"


def call_mcp(tool: str, params: dict, token: str) -> dict:
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": tool,
            "arguments": params,
        },
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        MCP_URL,
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        print(f"HTTP {e.code}: {body}", file=sys.stderr)
        sys.exit(1)

    if "error" in result:
        print(f"MCP Error: {result['error']}", file=sys.stderr)
        sys.exit(1)

    return result.get("result", {})


def main():
    parser = argparse.ArgumentParser(description="inkspcl.com MCP client")
    parser.add_argument("tool", help="MCP tool name, e.g. blog.create_post")
    parser.add_argument("--token", required=True, help="Bearer token")
    parser.add_argument("--params", default="{}", help="JSON params string")
    args = parser.parse_args()

    params = json.loads(args.params)
    result = call_mcp(args.tool, params, args.token)

    # Extract text content from MCP result
    if isinstance(result, dict):
        content = result.get("content", [])
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                print(item["text"])
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""inkspcl.com pyWork MCP client — JSON-RPC 2.0 over HTTP.

Features:
  - Call any MCP tool via JSON-RPC
  - Check for skill upgrades (--check-upgrade)
  - Auto-upgrade to latest version (--upgrade)
"""

import argparse
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.request
import urllib.error
import zipfile

MCP_URL = "https://www.inkspcl.com/mcp"
SKILL_INFO_URL = "https://www.inkspcl.com/api/skill/info"
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def call_mcp(tool: str, params: dict, token: str) -> dict:
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": tool,
            "arguments": params,
        },
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        MCP_URL,
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        print(f"HTTP {e.code}: {body}", file=sys.stderr)
        sys.exit(1)

    if "error" in result:
        print(f"MCP Error: {result['error']}", file=sys.stderr)
        sys.exit(1)

    return result.get("result", {})


def _read_local_version() -> str:
    """Read version from local SKILL.md front-matter."""
    skill_md = os.path.join(SKILL_DIR, "SKILL.md")
    if not os.path.exists(skill_md):
        return "0.0.0"
    with open(skill_md, "r", encoding="utf-8") as f:
        content = f.read()
    m = re.search(r'^version:\s*["\']?([^"\'\s]+)["\']?', content, re.MULTILINE)
    return m.group(1) if m else "0.0.0"


def _fetch_remote_info() -> dict:
    """Fetch latest skill info from server."""
    req = urllib.request.Request(SKILL_INFO_URL, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        print(f"Failed to fetch skill info: {e}", file=sys.stderr)
        sys.exit(1)


def _parse_version(v: str) -> tuple:
    """Parse semver string to tuple for comparison."""
    parts = v.lstrip("v").split(".")
    result = []
    for p in parts[:3]:
        try:
            result.append(int(p))
        except ValueError:
            result.append(0)
    while len(result) < 3:
        result.append(0)
    return tuple(result)


def check_upgrade() -> dict:
    """Check if a newer version is available. Returns info dict."""
    local_ver = _read_local_version()
    remote_info = _fetch_remote_info()
    remote_ver = remote_info.get("version", "0.0.0")
    has_update = _parse_version(remote_ver) > _parse_version(local_ver)
    return {
        "local_version": local_ver,
        "remote_version": remote_ver,
        "has_update": has_update,
        "download_url": remote_info.get("download_url", ""),
        "changelog": remote_info.get("changelog", ""),
    }


def perform_upgrade() -> None:
    """Download and install the latest skill version."""
    info = check_upgrade()
    if not info["has_update"]:
        print(f"Already up to date (v{info['local_version']})")
        return

    print(f"Upgrading: v{info['local_version']} → v{info['remote_version']}")
    if info["changelog"]:
        print(f"Changelog: {info['changelog']}")

    download_url = info["download_url"]
    if not download_url.startswith("http"):
        # Relative URL — prepend base
        base = MCP_URL.rsplit("/mcp", 1)[0]
        download_url = base + download_url

    # Download ZIP
    print(f"Downloading {download_url} ...")
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, "inkspcl-pywork.zip")
            urllib.request.urlretrieve(download_url, zip_path)

            # Extract
            with zipfile.ZipFile(zip_path, "r") as zf:
                # Find the top-level directory inside the zip
                namelist = zf.namelist()
                top_dir = namelist[0].split("/")[0]  # e.g. "inkspcl-pywork"
                zf.extractall(tmpdir)

            src_dir = os.path.join(tmpdir, top_dir)

            # Replace files in SKILL_DIR
            for item in os.listdir(src_dir):
                src_item = os.path.join(src_dir, item)
                dst_item = os.path.join(SKILL_DIR, item)
                if os.path.isdir(src_item):
                    if os.path.exists(dst_item):
                        shutil.rmtree(dst_item)
                    shutil.copytree(src_item, dst_item)
                else:
                    shutil.copy2(src_item, dst_item)

        print(f"Upgrade complete: v{info['remote_version']}")
    except Exception as e:
        print(f"Upgrade failed: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="inkspcl.com MCP client")
    parser.add_argument("tool", nargs="?", help="MCP tool name, e.g. blog.create_post")
    parser.add_argument("--token", help="Bearer token")
    parser.add_argument("--params", default="{}", help="JSON params string")
    parser.add_argument("--check-upgrade", action="store_true",
                        help="Check if a newer skill version is available")
    parser.add_argument("--upgrade", action="store_true",
                        help="Upgrade skill to the latest version")
    args = parser.parse_args()

    if args.check_upgrade:
        info = check_upgrade()
        print(f"Local version:  v{info['local_version']}")
        print(f"Latest version: v{info['remote_version']}")
        if info["has_update"]:
            print(f"Update available!")
            if info["changelog"]:
                print(f"Changelog: {info['changelog']}")
        else:
            print("Already up to date.")
        return

    if args.upgrade:
        perform_upgrade()
        return

    if not args.tool:
        parser.error("tool is required unless using --check-upgrade or --upgrade")

    if not args.token:
        parser.error("--token is required for MCP calls")

    params = json.loads(args.params)
    result = call_mcp(args.tool, params, args.token)

    # Extract text content from MCP result
    if isinstance(result, dict):
        content = result.get("content", [])
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                print(item["text"])
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
